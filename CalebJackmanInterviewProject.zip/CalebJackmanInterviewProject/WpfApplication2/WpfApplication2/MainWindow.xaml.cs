﻿//Caleb Jackman
//Eurosoft Inc. Interview Project
//May 24, 2018
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace WpfApplication2 {
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window {
		public MainWindow() {
			InitializeComponent();
		}
		protected string file;

		private void PrintFileToTextBox(string myFile, TextBox myTextbox) {
			//Prints given files content to given textbox
			myTextbox.Text = File.ReadAllText(myFile);
		}

		private void button1_Click(object sender, RoutedEventArgs e) {
			//Selects the file to use and displays said files contents
			OpenFileDialog openFileDialog = new OpenFileDialog();
			if (openFileDialog.ShowDialog()==true){
				file = openFileDialog.FileName;
				PrintFileToTextBox(file, textBoxOriginal);
			}
		}

		private void button_Click(object sender, RoutedEventArgs e) {
			//Reverses the current file top to bottom
			var lines = File.ReadAllLines(file).Reverse();
			File.WriteAllLines(file, lines);
			PrintFileToTextBox(file, textBoxAltered);
		}

		private void button2_Click(object sender, RoutedEventArgs e) {
			//Reverses the current file line by line left to right
			var lines = File.ReadAllLines(file);
			List<string> temp = new List<string>();
			foreach (string line in lines){
				char[] charArray = line.ToCharArray();
				Array.Reverse(charArray);
				temp.Add(new string(charArray));
			}
			File.WriteAllLines(file,temp);
			PrintFileToTextBox(file, textBoxAltered);
		}
	}
}
